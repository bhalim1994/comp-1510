/**
 * 
 */
package ca.bcit.comp1510.lab5;

import java.text.DecimalFormat;
import java.util.Scanner;

/**
 * GeometryDriver.
 * 
 * Tests the Sphere, Cube, and Cone classes.
 *
 * @author Benedict Halim
 * @version 1.0
 */

public class GeometryDriver {
    
    /**
     * Drives the program.
     *
     * @param args unused.
     */
    public static void main(String[] args) {
        // 2. Scanner object.
        Scanner scan = new Scanner(System.in);
        
        // 6. Decimal format.
        DecimalFormat formatter = new DecimalFormat("0.###");
        
        // 3. Sphere
        System.out.println("Please enter the X-Coordinate, Y-Coordinate, "
                + "Z-Coordinate, and radius of your sphere, "
                + "separated by spaces: ");
        Sphere sphere = new Sphere(scan.nextDouble(), scan.nextDouble(),
                scan.nextDouble(), scan.nextDouble());
        System.out.println("Your sphere's surface area is: "
                + formatter.format(sphere.surfaceArea()));
        System.out.println("Your sphere's volume is: "
                + formatter.format(sphere.volume()));
        
        // 4. Cube
        System.out.println("Please enter the X-Coordinate, Y-Coordinate, "
                + "Z-Coordinate, and edge length of your cube, "
                + "separated by spaces: ");
        Cube cube = new Cube(scan.nextDouble(), scan.nextDouble(),
                scan.nextDouble(), scan.nextDouble());
        System.out.println("Your cube's surface area is: "
                + formatter.format(cube.surfaceArea()));
        System.out.println(
                "Your cube's volume is: " + formatter.format(cube.volume()));
        System.out.println("Your cube's diagonal face is: "
                + formatter.format(cube.faceDiagonal()));
        System.out.println("Your cube's diagonal space is: "
                + formatter.format(cube.spaceDiagonal()));
        
        // 5. Cone
        System.out.println("Please enter the radius and height of your right "
                + "circular cone, separated by a space: ");
        Cone cone = new Cone(scan.nextDouble(), scan.nextDouble());
        System.out.println(
                "Your cone's volume is: " + formatter.format(cone.volume()));
        System.out.println("Your cone's slant height is: "
                + formatter.format(cone.slantHeight()));
        System.out.println("Your cone's surface area is: "
                + formatter.format(cone.surfaceArea()));
        
        scan.close();
    }
}
