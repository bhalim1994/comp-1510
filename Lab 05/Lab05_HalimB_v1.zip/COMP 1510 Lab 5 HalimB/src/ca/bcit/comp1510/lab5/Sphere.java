/**
 * 
 */
package ca.bcit.comp1510.lab5;

/**
 * Sphere.
 * 
 * Demonstrates the use of a constructor and its helper functions through a
 * Sphere object.
 * 
 * @author Benedict Halim
 * @version 1.0
 *
 */
public class Sphere {
    
    // 2. Private instance variables
    /**
     * X coordinate.
     */
    private double xCoordinate;
    /**
     * Y coordinate.
     */
    private double yCoordinate;
    /**
     * Z coordinate.
     */
    private double zCoordinate;
    /**
     * Radius of sphere.
     */
    private double radius;
    
    // 3. Constructor
    /**
     * Constructs a Sphere object that has an x coordinate, y coordinate, z
     * coordinate, and radius.
     * 
     * @param x Sphere's x coordinate.
     * @param y Sphere's y coordinate.
     * @param z Sphere's z coordinate.
     * @param r Sphere's radius.
     */
    public Sphere(double x, double y, double z, double r) {
        xCoordinate = x;
        yCoordinate = y;
        zCoordinate = z;
        radius = r;
    }
    
    // 4. Accessors
    
    /**
     * Gets the x coordinate of the sphere.
     * 
     * @return The sphere's x coordinate.
     */
    public double getXCoordinate() {
        return xCoordinate;
    }
    
    /**
     * Gets the y coordinate of the sphere.
     * 
     * @return The sphere's y coordinate.
     */
    public double getYCoordinate() {
        return yCoordinate;
    }
    
    /**
     * Gets the z coordinate of the sphere.
     * 
     * @return The sphere's z coordinate.
     */
    public double getZCoordinate() {
        return zCoordinate;
    }
    
    /**
     * Gets the radius of the sphere.
     * 
     * @return The sphere's radius.
     */
    public double getRadius() {
        return radius;
    }
    
    // 4. Mutators
    
    /**
     * Sets the x coordinate of the sphere.
     * 
     * @param x Sphere's x coordinate.
     */
    public void setXCoordinate(double x) {
        xCoordinate = x;
    }
    
    /**
     * Sets the y coordinate of the sphere.
     * 
     * @param y Sphere's y coordinate.
     */
    public void setYCoordinate(double y) {
        yCoordinate = y;
    }
    
    /**
     * Sets the z coordinate of the sphere.
     * 
     * @param z Sphere's z coordinate.
     */
    public void setZCoordinate(double z) {
        zCoordinate = z;
    }
    
    /**
     * Sets the radius of the sphere.
     * 
     * @param r Sphere's radius.
     */
    public void setRadius(double r) {
        radius = r;
    }
    
    // 5 & 6. Helper methods
    
    /**
     * Calculates the surface area of a sphere.
     * 
     * @return The sphere's surface area.
     */
    public double surfaceArea() {
        final double coefficient = 4.0;
        final int power = 2;
        return coefficient * Math.PI * Math.pow(radius, power);
    }
    
    /**
     * Calculates the volume of a sphere.
     * 
     * @return The sphere's volume.
     */
    public double volume() {
        final double coefficient = (4.0 / 3.0);
        final int power = 3;
        return coefficient * Math.PI * Math.pow(radius, power);
    }
    
    // 7. toString method.
    
    /**
     * Returns the sphere's X, Y, Z coordinates and its radius.
     * 
     * @return A concatenation of the sphere's 3 coordinates and radius.
     */
    public String toString() {
        return "X-Coordinate: " + xCoordinate + "\n" + "Y-Coordinate: "
                + yCoordinate + "\n" + "Z-Coordinate: " + zCoordinate + "\n"
                + "Radius: " + radius;
    }
    
}
