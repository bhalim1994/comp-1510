package ca.bcit.comp1510.lab5;

/**
 * Cone.
 * 
 * Demonstrates the use of a constructor and its helper functions through a Cone
 * object.
 * 
 * @author Benedict Halim
 * @version 1.0
 *
 */
public class Cone {
    
    // 3. Private instance variables.
    /**
     * Radius.
     */
    private double radius;
    /**
     * Height.
     */
    private double height;
    
    // 4. Constructor
    /**
     * Constructs a Cone object that has a radius and height.
     * 
     * @param h Cone's height.
     * @param r Cone's radius.
     */
    public Cone(double r, double h) {
        radius = r;
        height = h;
    }
    
    // 5. Accessors
    /**
     * Gets the radius of the cone.
     * 
     * @return The cone's radius.
     */
    public double getRadius() {
        return radius;
    }
    
    /**
     * Gets the height of the cone.
     * 
     * @return The cone's height.
     */
    public double getHeight() {
        return height;
    }
    
    /**
     * Sets the radius of the cone.
     * 
     * @param r Cone's radius.
     */
    public void setRadius(double r) {
        radius = r;
    }
    
    /**
     * Sets the height of the cone.
     * 
     * @param h Cone's height.
     */
    public void setHeight(double h) {
        height = h;
    }
    
    // 6.
    /**
     * Calculates the volume of a cone.
     * 
     * @return The cone's volume.
     */
    public double volume() {
        final double coefficient = 1.0 / 3.0;
        final int power = 2;
        return coefficient * Math.PI * Math.pow(radius, power) * height;
    }
    
    // 7.
    /**
     * Calculates the slant height of a cone.
     * 
     * @return The cone's slant height.
     */
    public double slantHeight() {
        final int power = 2;
        return Math.sqrt(Math.pow(radius, power) + Math.pow(height, power));
    }
    
    // 8.
    /**
     * Calculates the surface area of a cone.
     * 
     * @return The cone's surface area.
     */
    public double surfaceArea() {
        final int power = 2;
        return Math.PI * Math.pow(radius, power) + Math.PI * radius
                * Math.sqrt(Math.pow(radius, power) + Math.pow(height, power));
    }
    
    // 9.
    /**
     * Returns the cone's radius and height.
     * 
     * @return A concatenation of the cone's radius and height.
     */
    public String toString() {
        return "Radius: " + radius + "\n" + "Height: " + height;
    }
    
}
