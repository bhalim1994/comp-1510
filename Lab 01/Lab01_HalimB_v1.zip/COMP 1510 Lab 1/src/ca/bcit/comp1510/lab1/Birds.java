package ca.bcit.comp1510.lab1;

public class Birds {
    
    public static void main(String[] args) {
        System.out.println("Ten robins plus 13 canaries is " + (10 + 13) 
                + " birds.");
    }
    
}
