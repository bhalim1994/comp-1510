package ca.bcit.comp1510.lab1;

public class Poem {

    public static void main(String[] args) {
        System.out.println("Roses are red");
        System.out.println("Violets are blue");
        System.out.println("Sugar is sweet");
        System.out.println("But I have commitment issues");
        System.out.println("So I'd rather just be friends");
        System.out.println("At this point in our relationship.");
    }

}
