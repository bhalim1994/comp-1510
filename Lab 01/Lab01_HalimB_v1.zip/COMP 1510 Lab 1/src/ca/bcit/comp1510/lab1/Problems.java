package ca.bcit.comp1510.lab1;

public class Problems {

    public static void main(String[] args) {
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
        System.out.println("This program used to have lots of problems,");
        System.out.println("but if it prints this, you fixed them all.");
        System.out.println(" *** Hurray! ***");
        System.out.println("!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!!");
    }

}
