Benedict Halim, A01185587, 1B, October 20, 2019

This assignment is 100% complete.


------------------------
Question one (PhoneNumbers) status:

complete

------------------------
Question two (CylinderStats) status:

complete

------------------------
Question three (Cylinder) status:

complete

------------------------
Question four (Box) status:

complete

------------------------
Question five (Email) status:

complete
