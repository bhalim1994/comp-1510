[Benedict Halim], [A01185587], [1B], [November 17, 2019]

This assignment is 100% complete.


------------------------
Question one (WordCounter) status:

complete

Note: Takes 2-4 minutes to finish running the program as there are a lot of 
words. Please be patient when running it!

------------------------
Question two (Primes) status:

complete

------------------------
Question three (TestStudent and supporting classes) status:

complete

------------------------
Question four (TestCourse and supporting classes) status:

complete

------------------------
